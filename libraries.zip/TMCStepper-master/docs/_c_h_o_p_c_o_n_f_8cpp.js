var _c_h_o_p_c_o_n_f_8cpp =
[
    [ "GET_REG_2660", "_c_h_o_p_c_o_n_f_8cpp.html#aa0ca7f498936322233db718888dc1adc", null ],
    [ "SET_REG", "_c_h_o_p_c_o_n_f_8cpp.html#a6e4f7ba2fdd5a548e9a0383905ada143", null ]
];