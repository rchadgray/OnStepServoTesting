var class_s_switch =
[
    [ "SSwitch", "class_s_switch.html#a910f9f90a4c43e8b05a8c69ee0be9b94", null ],
    [ "active", "class_s_switch.html#a6ff09d0850d551571dc333fb74ff8628", null ]
];