var _i_h_o_l_d___i_r_u_n_8cpp =
[
    [ "GET_REG", "_i_h_o_l_d___i_r_u_n_8cpp.html#a851c499b52890f1c89886e8cf64a4415", null ],
    [ "SET_REG", "_i_h_o_l_d___i_r_u_n_8cpp.html#a6e4f7ba2fdd5a548e9a0383905ada143", null ]
];