var _d_r_v_s_t_a_t_u_s_8cpp =
[
    [ "GET_REG00", "_d_r_v_s_t_a_t_u_s_8cpp.html#a700e9ae9a224385dfd850ca2b7417e69", null ],
    [ "GET_REG01", "_d_r_v_s_t_a_t_u_s_8cpp.html#a2046ed225380d65752e579908d91aa51", null ],
    [ "GET_REG10", "_d_r_v_s_t_a_t_u_s_8cpp.html#a29f9f7ed99e65caeb204ba7cb3655f08", null ]
];